exports.host = "serverhaus.ddns.net";
exports.port = "8181";