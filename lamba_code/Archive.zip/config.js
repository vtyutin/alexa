var config = {
    appid: "amzn1.ask.skill.1a1d3548-3d83-4d10-83e2-16101633f247",
    url : "http://radio764.streamr.ru/",
    token : "user123456"
};

module.exports = config;