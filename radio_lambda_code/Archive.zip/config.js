var config = {
    appid: "amzn1.ask.skill.f8b188a7-854b-4801-90d7-2bb3d5366ad8",
    appindianid: "amzn1.ask.skill.2ea807ce-596f-4174-8e18-a89b8961d5fa",
    url: "https://s3.amazonaws.com/radiourl/playlist.m3u",
    indian_url: "https://live.stream2web.com/live/airbharati/playlist.m3u8",
    indian_url2: "https://live.stream2web.com/live/airbangla/playlist.m3u8",
    indian_url3: "https://live.stream2web.com/live/airtamil/playlist.m3u8",
    romantika_url: "https://s3.amazonaws.com/radiourl/radio_romantika_online.m3u",
    token: "radio1234567"
};

module.exports = config;