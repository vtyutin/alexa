var config = {
    appid: "amzn1.ask.skill.f8b188a7-854b-4801-90d7-2bb3d5366ad8",
    appindianid: "amzn1.ask.skill.c06c0033-a4b0-4c4d-a4f3-75f795765b10",
    url: "https://s3.amazonaws.com/radiourl/playlist.m3u",
    indian_url: "https://s3.amazonaws.com/radiourl/indian_radio.m3u",
    romantika_url: "https://s3.amazonaws.com/radiourl/radio_romantika_online.m3u",
    token: "radio1234567"
};

module.exports = config;