var config = {
    appid: "amzn1.ask.skill.f8b188a7-854b-4801-90d7-2bb3d5366ad8",
    url: "https://s3.amazonaws.com/radiourl/playlist.m3u8",
    romantika_url: "https://s3.amazonaws.com/radiourl/radio_romantika_online.m3u",
    token: "radio1234567"
};

module.exports = config;